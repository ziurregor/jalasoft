﻿// -------------------------------------------------------------- //
// <copyright file="Program.cs" company="ocp">
//     Copyright (c) 2018 Orlando Campos
//     License: MIT License
// </copyright>
// -------------------------------------------------------------- //
namespace Events
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var publisher = new Publisher();

            var subscriber1 = new Subscriber("Subscriber1", publisher);
            var subscriber2 = new Subscriber("Subscriber2", publisher);

            publisher.DoSomething();
            publisher.DoOtherThing();
        }
    }
}
