﻿// -------------------------------------------------------------- //
// <copyright file="CustomEventArgs.cs" company="ocp">
//     Copyright (c) 2018 Orlando Campos
//     License: MIT License
// </copyright>
// -------------------------------------------------------------- //
namespace Events
{
    public class CustomEventArgs
    {
        public CustomEventArgs(string message)
        {
            this.Message = message;
        }

        public string Message { get; set; }
    }
}
