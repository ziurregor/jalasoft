﻿// -------------------------------------------------------------- //
// <copyright file="Subscriber.cs" company="ocp">
//     Copyright (c) 2018 Orlando Campos
//     License: MIT License
// </copyright>
// -------------------------------------------------------------- //
namespace Events
{
    using System;
    using System.Threading;

    public class Subscriber
    {
        public Subscriber(string name, Publisher publisher)
        {
            this.Name = name;

            // 4. Subscribe the publisher's events to the subscriber's event handlers
            publisher.MyEvent += this.HandleMyEvent;
            publisher.OtherEvent += this.HandleOtherEvent;
        }

        private string Name { get; set; }

        private void HandleMyEvent(object sender, CustomEventArgs e)
        {
            var time = $"at {DateTime.Now.Hour}:{DateTime.Now.Minute}:{DateTime.Now.Second}.{DateTime.Now.Millisecond}";
            Console.WriteLine($"{this.Name} is handling my event {time}{Environment.NewLine}\tCustom event argument (message): {e.Message}");

            // Here the subscriber needs to do some operation by using the information from the event
            // simulating the operation with a sleep of 1 second
            Thread.Sleep(1000);
        }

        private void HandleOtherEvent(object sender, EventArgs e)
        {
            var time = $" at {DateTime.Now.Hour}:{DateTime.Now.Minute}:{DateTime.Now.Second}.{DateTime.Now.Millisecond}";
            Console.WriteLine($"{this.Name} is handling other event {time}");

            // Here the subscriber needs to do some operation by using the information from the event
            // simulating the operation with a sleep of 2 seconds
            Thread.Sleep(2000);
        }
    }
}
