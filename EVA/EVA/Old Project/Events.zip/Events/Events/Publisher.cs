﻿// -------------------------------------------------------------- //
// <copyright file="Publisher.cs" company="ocp">
//     Copyright (c) 2018 Orlando Campos
//     License: MIT License
// </copyright>
// -------------------------------------------------------------- //
namespace Events
{
    using System;

    public class Publisher
    {
        /// <summary>
        /// 1. Let's create a delegate that will be handled by the event
        /// </summary>
        /// <param name="sender">This is the object who raised the event</param>
        /// <param name="e">These are the custom event arguments to be evaluated once the event is raised</param>
        public delegate void MyCustomDelegate(object sender, CustomEventArgs e);

        /// <summary>
        /// 2. Let's declare an event that will handle our custom delegate (MyDelegate)
        /// </summary>
        public event MyCustomDelegate MyEvent;

        /// <summary>
        /// 2'. This is an alternative way of declare an event that is not using the custom delegate created (MyDelegate)
        /// Instead is using a delegate (EventHandler) provided by the .Net framework
        /// </summary>
        public event EventHandler<EventArgs> OtherEvent;

        public void DoSomething()
        {
            // Here we should have the code that is doing some operation

            // 3. After the operation we raise an event as a notification that the operation was completed.
            this.OnRaiseMyEvent(new CustomEventArgs("Notification that is raised after something was completed"));
        }

        public void DoOtherThing()
        {
            // Here we should have the code that is doing some operation

            // 3'. After the operation we raise an event as a notification that the operation was completed.
            this.OnRaiseOtherEvent(new EventArgs());
        }

        protected virtual void OnRaiseMyEvent(CustomEventArgs e)
        {
            // This is the custom delegate we created
            MyCustomDelegate myCustomDelegate = this.MyEvent;

            if (this.MyEvent != null)
            {
                myCustomDelegate(this, e);
            }
        }

        protected virtual void OnRaiseOtherEvent(EventArgs e)
        {
            // This is the generic delegate provided by the .Net Framework
            EventHandler<EventArgs> dotnetFrameworkDelegate = this.OtherEvent;

            if (this.OtherEvent != null)
            {
                dotnetFrameworkDelegate(this, e);
            }
        }
    }
}
