﻿// -------------------------------------------------------------- //
// <copyright file="Program.cs" company="ocp">
//     Copyright (c) 2018 Orlando Campos
//     License: MIT License
// </copyright>
// -------------------------------------------------------------- //
namespace NullableTypes
{
    using System;

    public class Program
    {
        public static void Main(string[] args)
        {
            // They are types that allow us to use null values in value types
            // Are instances of the System.Nullable<T> struct.
            // Usefull when you are dealing with databases on other data types that contain elements that may not be assigned a value.
            //// The sintax T? i a shorthand for Nullable<T>.

            Console.WriteLine("*** T?");

            int? nullableInteger = null;
            PrintInConsole(nullableInteger);
            nullableInteger = 10;
            PrintInConsole(nullableInteger);

            Console.WriteLine();
            Console.WriteLine("*** Nullable<T>");

            Nullable<int> nullableInt = null;
            PrintInConsole(nullableInt);
            nullableInt = 666;
            PrintInConsole(nullableInt);
            Console.WriteLine();

            #region Explicit conversion with nullable types

            int? number = null;
            ////int other = number; // This will not compile
            ////int number2 = (int)number; // It compiles, but it will throw an exception if number is null (runtime error)
            ////int number3 = number.Value // It compiles, but it will throw an exception if number is null (runtime error)

            #endregion

            #region Implicit conversion with nullable types

            int? otherNumber;
            otherNumber = 666; // Implicit conversion
            Console.WriteLine("Printed nullable type after implicit conversion: " + otherNumber);

            #endregion

            #region The ?? operator

            Console.WriteLine();
            Console.WriteLine("**************** Example 1 for ??");
            int? c = null;

            // d = c, unless c is null, in which case d = -1.
            int d = c ?? -1;
            Console.WriteLine("int? c = " + (c.HasValue ? c.Value.ToString() : "null"));
            Console.WriteLine("int d = c ?? -1;");
            Console.WriteLine("d = " + d);

            Console.WriteLine();
            Console.WriteLine("**************** Example 2 for ??");

            int? e = null;
            int? f = null;

            // g = e or f, unless e and f are both null, in which case g = -1.
            int g = e ?? f ?? -1;
            Console.WriteLine("int? e = " + (e.HasValue ? e.Value.ToString() : "null"));
            Console.WriteLine("int? f = " + (f.HasValue ? f.Value.ToString() : "null"));
            Console.WriteLine("int g = e ?? f ?? -1;");
            Console.WriteLine("g = " + g);

            #endregion
        }

        public static void PrintInConsole(int? nullableInteger)
        {
            if (nullableInteger.HasValue)
            {
                //// System.Console.WriteLine(nullableInteger);
                System.Console.WriteLine(nullableInteger.Value);
            }
            else
            {
                System.Console.WriteLine("Undefined");
            }
        }
    }
}
