﻿using System;
using System.Collections.Generic;
using Model;
namespace DAO
{
    public class LiteralRepository
    {
        public List<Literal> literals = new List<Literal>();
        public LiteralRepository()
        {
        }

        public static void CreateLiteral(Literal literal) {
            literals.Add(literal);
        }
    }
}
