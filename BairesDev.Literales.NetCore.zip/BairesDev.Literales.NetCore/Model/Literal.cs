﻿using System;
namespace Model
{
    public class Literal
    {
        public int Code { get; set; }
        public String Descripcion { get; set; }
        public Boolean Plural { get; set; }
        public String Variables { get; set; }
    }
}
